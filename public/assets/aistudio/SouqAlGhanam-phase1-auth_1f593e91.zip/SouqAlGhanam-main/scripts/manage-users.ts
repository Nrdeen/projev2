/**
 * Operator CLI for account management. Passwords are read from a hidden prompt (or the
 * ADMIN_PASSWORD env var for automation) and are never written to the repo or the console.
 *
 *   npm run user:create-admin -- --phone 05XXXXXXXX --name "الاسم"
 *   npm run user:set-password -- --phone 05XXXXXXXX
 */
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';
import { createUserRecord } from '../server/auth/accounts';
import { normalizeSaudiMobile, validatePassword } from '../server/auth/phone';
import { hashPassword } from '../server/auth/password';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
const STORE_PATH = path.join(DATA_DIR, 'store.json');

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(`--${name}`);
  return i !== -1 ? process.argv[i + 1] : undefined;
}

function askHidden(question: string): Promise<string> {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    const write = (rl as any)._writeToOutput;
    (rl as any)._writeToOutput = (text: string) => {
      if (text.startsWith(question)) write.call(rl, text);
    };
    rl.question(question, (answer) => {
      rl.close();
      process.stdout.write('\n');
      resolve(answer);
    });
  });
}

async function getPassword(phone: string): Promise<string> {
  const fromEnv = process.env.ADMIN_PASSWORD;
  const password = fromEnv ?? (await askHidden('كلمة المرور (10 أحرف على الأقل): '));
  if (!fromEnv) {
    const again = await askHidden('أعد إدخال كلمة المرور: ');
    if (again !== password) throw new Error('كلمتا المرور غير متطابقتين');
  }
  const problem = validatePassword(password, phone);
  if (problem) throw new Error(problem);
  return password;
}

async function main() {
  const command = process.argv[2];
  if (!fs.existsSync(STORE_PATH)) throw new Error(`Store not found at ${STORE_PATH}. Start the server once first.`);
  const raw = fs.readFileSync(STORE_PATH, 'utf-8');
  const store = JSON.parse(raw);
  store.credentials ??= [];

  const phone = normalizeSaudiMobile(arg('phone'));
  if (!phone) throw new Error('رقم الجوال غير صحيح، استخدم --phone 05XXXXXXXX');

  // Safety copy before touching real data.
  const backupDir = path.join(DATA_DIR, 'backups');
  fs.mkdirSync(backupDir, { recursive: true });
  fs.writeFileSync(path.join(backupDir, `store.pre-cli-${Date.now()}.json`), raw, { mode: 0o600 });

  if (command === 'create-admin') {
    const name = arg('name') || 'إدارة المنصة';
    if (store.users.some((u: any) => u.phone === phone)) {
      throw new Error('الرقم مسجل مسبقاً. لتغيير كلمة المرور استخدم set-password.');
    }
    const password = await getPassword(phone);
    const user = createUserRecord({ name, phone, role: 'admin' });
    store.users.push(user);
    store.credentials.push({ userId: user.id, passwordHash: await hashPassword(password), updatedAt: new Date().toISOString() });
    console.log(`تم إنشاء المشرف ${user.name} (${user.id}).`);
  } else if (command === 'set-password') {
    const user = store.users.find((u: any) => u.phone === phone);
    if (!user) throw new Error('لا يوجد حساب بهذا الرقم');
    if (user.isDemo && process.env.NODE_ENV === 'production') throw new Error('الحسابات التجريبية لا تُفعَّل في الإنتاج');
    const password = await getPassword(phone);
    const hash = await hashPassword(password);
    const existing = store.credentials.find((c: any) => c.userId === user.id);
    if (existing) {
      existing.passwordHash = hash;
      existing.updatedAt = new Date().toISOString();
    } else {
      store.credentials.push({ userId: user.id, passwordHash: hash, updatedAt: new Date().toISOString() });
    }
    // A password change ends every existing session for that account.
    store.sessions = (store.sessions || []).filter((s: any) => s.userId !== user.id);
    console.log(`تم تعيين كلمة مرور جديدة للحساب ${user.id} وإنهاء جلساته الحالية.`);
  } else {
    throw new Error('Usage: manage-users.ts <create-admin|set-password> --phone 05XXXXXXXX [--name "..."]');
  }

  const tmp = `${STORE_PATH}.cli.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(store, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, STORE_PATH);
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
