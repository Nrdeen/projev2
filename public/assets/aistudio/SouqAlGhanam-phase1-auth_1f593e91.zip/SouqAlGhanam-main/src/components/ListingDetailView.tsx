import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  ArrowRight,
  BadgeDollarSign,
  Check,
  CheckCircle2,
  Copy,
  Flag,
  Heart,
  MessageSquare,
  Phone,
  Plus,
  Scale,
  Share2,
  ShieldCheck,
  Trash2,
  User as UserIcon,
  X,
  XCircle,
} from 'lucide-react';
import type {
  Breed,
  Category,
  Listing,
  PriceOffer,
  Region,
  SellerProfile,
  User,
} from '../types/marketplace';
import { formatPriceSar, formatRelativeArabicTime, formatStatusLabel } from '../lib/format';
import { SafeImage } from './SafeImage';
import { Modal } from './Modal';

interface ListingDetailViewProps {
  listing: Listing;
  /** null for visitors who are not signed in. */
  currentUser: User | null;
  category?: Category;
  subCategory?: Category;
  breed?: Breed;
  region?: Region;
  seller?: SellerProfile;
  offers: PriceOffer[];
  isFavorite: boolean;
  onBack: () => void;
  onToggleFavorite: (listingId: string) => void;
  onStartConversation: (listingId: string, initialMessage: string) => Promise<void>;
  onSubmitPriceOffer: (
    listingId: string,
    payload: { offeredPrice: number; quantity: number; note: string }
  ) => Promise<void>;
  onRespondToOffer: (offerId: string, status: 'accepted' | 'rejected') => Promise<void>;
  onReportListing: (listingId: string, reason: string, details: string) => Promise<void>;
  onOpenSellerProfile: (sellerId: string) => void;
  onNotify?: (message: string) => void;
  comparableListings: Listing[];
  allCategories: Category[];
  allBreeds: Breed[];
  allRegions: Region[];
  allSellers: SellerProfile[];
  compareIds: string[];
  compareListings: Listing[];
  onToggleCompare: (listingId: string) => void;
  onClearCompare: () => void;
  onSelectListing: (listing: Listing) => void;
}

export function ListingDetailView({
  listing,
  currentUser,
  category,
  subCategory,
  breed,
  region,
  seller,
  offers,
  isFavorite,
  onBack,
  onToggleFavorite,
  onStartConversation,
  onSubmitPriceOffer,
  onRespondToOffer,
  onReportListing,
  onOpenSellerProfile,
  onNotify,
  comparableListings,
  allCategories,
  allBreeds,
  allRegions,
  allSellers,
  compareIds,
  compareListings,
  onToggleCompare,
  onClearCompare,
  onSelectListing,
}: ListingDetailViewProps) {
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [messageText, setMessageText] = useState(
    `السلام عليكم، أستفسر عن إعلان: ${listing.title}`
  );
  const [sendingMsg, setSendingMsg] = useState(false);
  const [msgSuccess, setMsgSuccess] = useState(false);

  // Price Offer / Negotiation Modal State
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [offeredPrice, setOfferedPrice] = useState(
    String(listing.expectedPrice || Math.round((listing.priceAmount * 0.92) / 10) * 10)
  );
  const [offerQuantity, setOfferQuantity] = useState('1');
  const [offerNote, setOfferNote] = useState('');
  const [offerSubmitting, setOfferSubmitting] = useState(false);
  const [offerError, setOfferError] = useState('');
  const [offerSuccess, setOfferSuccess] = useState(false);

  // Report Modal State
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('بيانات غير مطابقة');
  const [reportDetails, setReportDetails] = useState('');
  const [reportSent, setReportSent] = useState(false);
  const [showPhone, setShowPhone] = useState(false);

  // Share Listing State
  const [copiedLink, setCopiedLink] = useState(false);
  const copyTimerRef = useRef<number | null>(null);

  // Livestock Comparison State
  const [comparePickId, setComparePickId] = useState('');
  const [showDiffsOnly, setShowDiffsOnly] = useState(false);
  const compareSectionRef = useRef<HTMLDivElement | null>(null);

  const isInCompare = compareIds.includes(listing.id);
  const availableToCompare = useMemo(
    () =>
      comparableListings.filter(
        (item) => !compareIds.includes(item.id)
      ),
    [comparableListings, compareIds]
  );

  useEffect(() => {
    if (availableToCompare.length > 0 && !availableToCompare.some((l) => l.id === comparePickId)) {
      const nextPreferred =
        availableToCompare.find((l) => l.id !== listing.id) || availableToCompare[0];
      setComparePickId(nextPreferred.id);
    } else if (availableToCompare.length === 0) {
      setComparePickId('');
    }
  }, [availableToCompare, comparePickId, listing.id]);

  useEffect(() => {
    return () => {
      if (copyTimerRef.current !== null) {
        window.clearTimeout(copyTimerRef.current);
      }
    };
  }, []);

  const images =
    listing.images.length > 0
      ? listing.images
      : [{ id: 'default', url: breed?.imageUrl || '', position: 1 }];
  const currentImage = images[activeImageIdx]?.url || images[0]?.url;

  const allowsOffers =
    listing.allowPriceOffers !== undefined ? listing.allowPriceOffers : listing.isNegotiable;
  const isOwner = !!currentUser && currentUser.id === listing.sellerId;
  const canRespondOffers = isOwner || currentUser?.role === 'admin';
  const listingOffers = offers.filter((o) => o.listingId === listing.id);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    setSendingMsg(true);
    try {
      await onStartConversation(listing.id, messageText.trim());
      setMsgSuccess(true);
    } catch {
      // Visitors are redirected to the login page by the app; other errors surface via the app toast.
    } finally {
      setSendingMsg(false);
    }
  };

  const handleOpenOfferModal = () => {
    setOfferError('');
    setOfferedPrice(
      String(listing.expectedPrice || Math.round((listing.priceAmount * 0.92) / 10) * 10)
    );
    setOfferQuantity('1');
    setOfferNote('');
    setShowOfferModal(true);
  };

  const handleOfferSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setOfferError('');
    const parsedPrice = Number(offeredPrice);
    const parsedQty = Number(offerQuantity);
    if (!parsedPrice || Number.isNaN(parsedPrice) || parsedPrice <= 0) {
      setOfferError('يرجى إدخال قيمة عرض سعر صحيحة بالريال السعودي');
      return;
    }
    if (!parsedQty || parsedQty < 1 || parsedQty > listing.quantity) {
      setOfferError(`الكمية يجب أن تكون بين 1 و ${listing.quantity} رأس`);
      return;
    }
    setOfferSubmitting(true);
    setOfferSuccess(false);
    try {
      await onSubmitPriceOffer(listing.id, {
        offeredPrice: parsedPrice,
        quantity: parsedQty,
        note: offerNote.trim(),
      });
      setShowOfferModal(false);
      setOfferSuccess(true);
    } catch (err: any) {
      setOfferError(err?.message || 'تعذر إرسال عرض السعر');
    } finally {
      setOfferSubmitting(false);
    }
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onReportListing(listing.id, reportReason, reportDetails);
    setReportSent(true);
    setTimeout(() => {
      setShowReportModal(false);
      setReportSent(false);
      setReportDetails('');
    }, 1200);
  };

  const formatOfferStatus = (status: PriceOffer['status']) => {
    if (status === 'accepted') return 'عرض مقبول';
    if (status === 'rejected') return 'عرض مرفوض';
    return 'بانتظار رد المربي';
  };

  const offerTotal =
    (Number(offeredPrice) > 0 ? Number(offeredPrice) : 0) *
    (Number(offerQuantity) > 0 ? Number(offerQuantity) : 1);

  const shareUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}${window.location.pathname}?listing=${encodeURIComponent(listing.id)}`
      : `?listing=${encodeURIComponent(listing.id)}`;
  const locationLabel = region?.name ? `${region.name} — ${listing.city}` : listing.city;
  const shareSummary = `${listing.title} · السعر: ${formatPriceSar(listing.priceAmount)} · ${locationLabel}`;
  const whatsappShareHref = `https://wa.me/?text=${encodeURIComponent(`${shareSummary}\n${shareUrl}`)}`;
  const twitterShareHref = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareSummary)}&url=${encodeURIComponent(shareUrl)}`;
  const supportsNativeShare =
    typeof navigator !== 'undefined' && typeof navigator.share === 'function';

  const handleCopyShareLink = async () => {
    let copied = false;
    if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(shareUrl);
        copied = true;
      } catch {
        copied = false;
      }
    }

    if (!copied && typeof document !== 'undefined') {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = shareUrl;
        textarea.setAttribute('readonly', '');
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        copied = document.execCommand('copy');
        document.body.removeChild(textarea);
      } catch {
        copied = false;
      }
    }

    if (copied) {
      setCopiedLink(true);
      if (copyTimerRef.current !== null) {
        window.clearTimeout(copyTimerRef.current);
      }
      copyTimerRef.current = window.setTimeout(() => {
        setCopiedLink(false);
        copyTimerRef.current = null;
      }, 2500);
      onNotify?.('تم نسخ رابط الإعلان إلى الحافظة');
    } else {
      onNotify?.('تعذر النسخ التلقائي، يمكنك نسخ الرابط يدوياً');
    }
  };

  const handleNativeShare = async () => {
    if (!supportsNativeShare) return;
    try {
      await navigator.share({
        title: listing.title,
        text: shareSummary,
        url: shareUrl,
      });
    } catch {
      // User cancelled or share dismissed
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb Back */}
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 text-sm font-medium text-[var(--color-green-ink)] hover:underline mb-6 cursor-pointer"
      >
        <ArrowRight size={16} aria-hidden="true" />
        <span>العودة إلى الإعلانات</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Right Column in RTL: Gallery + Structured Specs + Negotiation Offers */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-[var(--color-cream)] rounded-xl border border-[var(--color-border)] overflow-hidden">
            <div className="aspect-[4/3] w-full">
              <SafeImage
                src={currentImage}
                alt={listing.title}
                className="w-full h-full object-cover"
              />
            </div>

            {images.length > 1 && (
              <div className="p-3 flex items-center gap-3 overflow-x-auto border-t border-[var(--color-border)] bg-[var(--color-surface)]">
                {images.map((img, idx) => (
                  <button
                    key={img.id}
                    type="button"
                    onClick={() => setActiveImageIdx(idx)}
                    className={`w-20 h-16 rounded-lg overflow-hidden border-2 shrink-0 cursor-pointer ${
                      idx === activeImageIdx
                        ? 'border-[var(--color-green-ink)]'
                        : 'border-transparent opacity-70'
                    }`}
                  >
                    <SafeImage
                      src={img.url}
                      alt={`${listing.title} - صورة ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Structured Specifications */}
          <div className="bg-[var(--color-surface)] rounded-xl border border-[var(--color-border)] p-6">
            <h2 className="font-display text-lg font-bold text-[var(--color-ink)] mb-4">
              المواصفات التفصيلية
            </h2>
            <dl className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="p-3 rounded-lg bg-[var(--color-cream)]/70">
                <dt className="text-xs text-[var(--color-muted)]">التصنيف والسلالة</dt>
                <dd className="mt-1 text-sm font-semibold text-[var(--color-ink)]">
                  {category?.name || 'أغنام'} — {breed?.name || 'غير محدد'}
                  {subCategory ? ` (${subCategory.name})` : ''}
                </dd>
              </div>
              <div className="p-3 rounded-lg bg-[var(--color-cream)]/70">
                <dt className="text-xs text-[var(--color-muted)]">العمر التقريبي</dt>
                <dd className="mt-1 text-sm font-semibold text-[var(--color-ink)] tabular-nums">
                  {listing.ageMonths} أشهر
                </dd>
              </div>
              <div className="p-3 rounded-lg bg-[var(--color-cream)]/70">
                <dt className="text-xs text-[var(--color-muted)]">الوزن التقريبي</dt>
                <dd className="mt-1 text-sm font-semibold text-[var(--color-ink)] tabular-nums">
                  {listing.weightKg} كجم
                </dd>
              </div>
              <div className="p-3 rounded-lg bg-[var(--color-cream)]/70">
                <dt className="text-xs text-[var(--color-muted)]">الجنس</dt>
                <dd className="mt-1 text-sm font-semibold text-[var(--color-ink)]">{listing.sex}</dd>
              </div>
              <div className="p-3 rounded-lg bg-[var(--color-cream)]/70">
                <dt className="text-xs text-[var(--color-muted)]">العدد المتاح</dt>
                <dd className="mt-1 text-sm font-semibold text-[var(--color-ink)] tabular-nums">
                  {listing.quantity} رأس
                </dd>
              </div>
              <div className="p-3 rounded-lg bg-[var(--color-cream)]/70">
                <dt className="text-xs text-[var(--color-muted)]">التحصين البيطري</dt>
                <dd className="mt-1 text-sm font-semibold text-[var(--color-green-ink)]">
                  {listing.vaccinated ? 'محصّن (دموي ومعوي)' : 'حسب المعاينة'}
                </dd>
              </div>
            </dl>

            <div className="mt-6 pt-6 border-t border-[var(--color-border)]">
              <h3 className="font-display text-base font-bold text-[var(--color-ink)] mb-2">
                وصف البائع
              </h3>
              <p className="text-sm text-[var(--color-ink)]/90 leading-relaxed whitespace-pre-line">
                {listing.description}
              </p>
            </div>
          </div>

          {/* Price Offers / Negotiation Log */}
          {allowsOffers && (
            <div className="bg-[var(--color-surface)] rounded-xl border border-[var(--color-border)] p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[var(--color-border)]">
                <div>
                  <h2 className="font-display text-lg font-bold text-[var(--color-ink)]">
                    سجل عروض الأسعار والتفاوض ({listingOffers.length})
                  </h2>
                  <p className="text-xs text-[var(--color-muted)] mt-0.5">
                    عروض السوم المقدمة من المشترين على هذا الإعلان مع حالة رد المربي
                  </p>
                </div>

                {!isOwner && (
                  <button
                    type="button"
                    onClick={handleOpenOfferModal}
                    className="px-4 py-2 rounded-lg bg-[var(--color-green)] hover:bg-[var(--color-green-hover)] text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <BadgeDollarSign size={15} aria-hidden="true" />
                    <span>تقديم عرض سعر</span>
                  </button>
                )}
              </div>

              {listingOffers.length === 0 ? (
                <p className="mt-4 text-sm text-[var(--color-muted)]">
                  لا توجد عروض أسعار مقدمة حتى الآن. كن أول من يقدم سومة للمربي.
                </p>
              ) : (
                <div className="mt-4 divide-y divide-[var(--color-border)]">
                  {listingOffers.map((offer) => (
                    <div
                      key={offer.id}
                      className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center flex-wrap gap-2 text-xs text-[var(--color-muted)]">
                          <span className="font-semibold text-[var(--color-ink)]">
                            {offer.buyerName}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">الكمية: {offer.quantity} رأس</span>
                          <span aria-hidden="true">·</span>
                          <span>{formatRelativeArabicTime(offer.createdAt)}</span>
                        </div>
                        <p className="font-display text-base font-extrabold text-[var(--color-green-ink)] tabular-nums mt-1">
                          {formatPriceSar(offer.offeredPrice)} للرأس
                          <span className="text-xs font-medium text-[var(--color-muted)] mr-2">
                            (الإجمالي: {formatPriceSar(offer.offeredPrice * offer.quantity)})
                          </span>
                        </p>
                        {offer.note && (
                          <p className="text-xs text-[var(--color-muted)] mt-1">{offer.note}</p>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span
                          className={`text-xs font-semibold ${
                            offer.status === 'accepted'
                              ? 'text-[var(--color-green-ink)]'
                              : offer.status === 'rejected'
                              ? 'text-red-700 dark:text-red-400'
                              : 'text-[var(--color-gold)]'
                          }`}
                        >
                          {formatOfferStatus(offer.status)}
                        </span>

                        {canRespondOffers && offer.status === 'pending' && (
                          <div className="flex items-center gap-1.5 mr-2">
                            <button
                              type="button"
                              onClick={() => onRespondToOffer(offer.id, 'accepted')}
                              className="px-3 py-1.5 rounded-lg bg-[var(--color-green)] hover:bg-[var(--color-green-hover)] text-white text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                            >
                              <CheckCircle2 size={13} aria-hidden="true" />
                              <span>قبول</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => onRespondToOffer(offer.id, 'rejected')}
                              className="px-3 py-1.5 rounded-lg border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-950/40 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                            >
                              <XCircle size={13} aria-hidden="true" />
                              <span>رفض</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Left Column in RTL: Contiguous Purchase & Contact Module */}
        <div className="lg:col-span-5 space-y-5 lg:sticky lg:top-24">
          <div className="bg-[var(--color-surface)] rounded-xl border border-[var(--color-border)] p-6">
            {/* Unboxed Metadata */}
            <div className="flex items-center flex-wrap gap-2 text-xs text-[var(--color-muted)] mb-2">
              <span className="font-semibold text-[var(--color-green-ink)]">
                حالة الإعلان: {formatStatusLabel(listing.status)}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {region?.name} — {listing.city}
              </span>
              <span aria-hidden="true">·</span>
              <span>{formatRelativeArabicTime(listing.publishedAt)}</span>
            </div>

            <h1 className="font-display text-2xl font-extrabold text-[var(--color-ink)] leading-snug text-balance">
              {listing.title}
            </h1>

            <div className="mt-4 pt-4 border-t border-[var(--color-border)] flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="text-xs text-[var(--color-muted)]">السعر المطلوب للرأس</p>
                <p className="font-display text-3xl font-extrabold text-[var(--color-green-ink)] tabular-nums mt-0.5">
                  {formatPriceSar(listing.priceAmount)}
                </p>
              </div>

              {listing.expectedPrice && listing.expectedPrice > 0 && (
                <div className="text-left">
                  <p className="text-xs text-[var(--color-muted)]">السعر المتوقع للتفاوض</p>
                  <p className="font-display text-lg font-bold text-[var(--color-ink)] tabular-nums mt-0.5">
                    {formatPriceSar(listing.expectedPrice)}
                  </p>
                </div>
              )}
            </div>

            <p className="mt-2 text-xs font-medium text-[var(--color-muted)]">
              {allowsOffers
                ? 'ميزة تقديم عرض سعر مفعّلة · يقبل السوم والتفاوض'
                : listing.isNegotiable
                ? 'السعر قابل للتفاوض'
                : 'سعر نهائي'}
            </p>

            {/* Primary Negotiation & Contact Buttons */}
            <div className="mt-5 space-y-2.5">
              {allowsOffers && !isOwner && (
                <button
                  type="button"
                  onClick={handleOpenOfferModal}
                  className="w-full h-11 px-4 rounded-lg bg-[var(--color-gold)] hover:bg-[var(--color-gold-hover)] text-[#14261D] text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <BadgeDollarSign size={17} aria-hidden="true" />
                  <span>تقديم عرض سعر للمربي (سوم)</span>
                </button>
              )}
              {offerSuccess && (
                <p className="text-xs font-medium text-[var(--color-green-ink)] bg-[var(--color-cream)] border border-[var(--color-border)] rounded-lg px-3 py-2">
                  تم تسجيل عرض سعرك وإشعار المربي به، ويمكنك متابعة الرد في سجل العروض أدناه أو من لوحة حسابي.
                </p>
              )}

              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => setShowPhone((p) => !p)}
                  className="flex-1 min-w-[160px] h-11 px-4 rounded-lg bg-[var(--color-green)] hover:bg-[var(--color-green-hover)] text-white text-sm font-semibold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Phone size={16} aria-hidden="true" />
                  <span className="tabular-nums">
                    {showPhone
                      ? seller?.phone || 'سجّل الدخول لعرض رقم البائع'
                      : 'إظهار رقم البائع'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => onToggleFavorite(listing.id)}
                  className={`h-11 px-4 rounded-lg border text-sm font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer ${
                    isFavorite
                      ? 'bg-[var(--color-cream)] border-[var(--color-gold)] text-[var(--color-green-ink)]'
                      : 'bg-[var(--color-surface)] border-[var(--color-border)] text-[var(--color-ink)] hover:bg-[var(--color-cream)]'
                  }`}
                >
                  <Heart size={16} fill={isFavorite ? 'var(--color-gold)' : 'none'} />
                  <span>{isFavorite ? 'في المفضلة' : 'حفظ'}</span>
                </button>

                <button
                  type="button"
                  aria-pressed={isInCompare}
                  onClick={() => onToggleCompare(listing.id)}
                  className={`h-11 px-4 rounded-lg border text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isInCompare
                      ? 'bg-[var(--color-cream)] border-[var(--color-green-ink)] text-[var(--color-green-ink)]'
                      : 'bg-[var(--color-surface)] border-[var(--color-border)] text-[var(--color-ink)] hover:bg-[var(--color-cream)]'
                  }`}
                >
                  <Scale size={16} aria-hidden="true" />
                  <span>{isInCompare ? 'في المقارنة' : 'أضف للمقارنة'}</span>
                </button>
              </div>

              {compareListings.length > 0 && (
                <button
                  type="button"
                  onClick={() =>
                    compareSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
                  }
                  className="text-xs font-semibold text-[var(--color-green-ink)] hover:underline inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Scale size={13} aria-hidden="true" />
                  <span className="tabular-nums">
                    عرض جدول مقارنة المواشي ({compareListings.length} / 4)
                  </span>
                </button>
              )}
            </div>

            {/* Share Listing Bar */}
            <div className="mt-5 pt-4 border-t border-[var(--color-border)]">
              <div className="flex items-center justify-between gap-2 mb-2.5">
                <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--color-ink)]">
                  <Share2 size={14} className="text-[var(--color-green-ink)]" aria-hidden="true" />
                  <span>مشاركة الإعلان</span>
                </span>
                <span className="text-[11px] text-[var(--color-muted)]">
                  انسخ الرابط أو شاركه مباشرة
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyShareLink}
                  className={`h-10 px-3.5 rounded-lg border text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    copiedLink
                      ? 'bg-[var(--color-cream)] border-[var(--color-green-ink)] text-[var(--color-green-ink)]'
                      : 'bg-[var(--color-surface)] border-[var(--color-border)] text-[var(--color-ink)] hover:bg-[var(--color-cream)]'
                  }`}
                >
                  {copiedLink ? (
                    <Check size={14} aria-hidden="true" />
                  ) : (
                    <Copy size={14} aria-hidden="true" />
                  )}
                  <span>{copiedLink ? 'تم نسخ الرابط' : 'نسخ الرابط'}</span>
                </button>

                <a
                  href={whatsappShareHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="مشاركة الإعلان عبر واتساب"
                  className="h-10 px-3.5 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] hover:bg-[var(--color-cream)] text-xs font-semibold text-[var(--color-green-ink)] inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="w-3.5 h-3.5 fill-current"
                    aria-hidden="true"
                  >
                    <path d="M12.04 2a9.93 9.93 0 0 0-8.5 15.05L2 22l5.1-1.34A9.93 9.93 0 1 0 12.04 2Zm5.78 14.08c-.24.68-1.4 1.3-1.94 1.38-.5.07-1.13.1-1.82-.12-.42-.14-.96-.32-1.65-.62-2.9-1.25-4.79-4.18-4.93-4.37-.14-.2-1.18-1.57-1.18-3 0-1.42.74-2.12 1-2.41.27-.29.58-.36.77-.36h.56c.18 0 .42-.07.66.5.24.58.82 2 .9 2.14.07.14.12.31.02.5-.1.2-.15.32-.29.49-.15.17-.3.38-.44.51-.14.15-.3.3-.13.59.17.29.75 1.24 1.61 2.01 1.11.99 2.04 1.3 2.33 1.44.29.15.46.12.63-.07.17-.2.72-.84.91-1.13.2-.29.39-.24.65-.15.27.1 1.68.8 1.97.94.29.15.48.22.55.34.07.12.07.7-.17 1.38Z" />
                  </svg>
                  <span>واتساب</span>
                </a>

                <a
                  href={twitterShareHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="مشاركة الإعلان عبر تويتر X"
                  className="h-10 px-3.5 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] hover:bg-[var(--color-cream)] text-xs font-semibold text-[var(--color-ink)] inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="w-3.5 h-3.5 fill-current"
                    aria-hidden="true"
                  >
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                  <span>تويتر (X)</span>
                </a>

                {supportsNativeShare && (
                  <button
                    type="button"
                    onClick={handleNativeShare}
                    className="h-10 px-3.5 rounded-lg border border-[var(--color-border)] bg-[var(--color-cream)]/60 hover:bg-[var(--color-cream)] text-xs font-semibold text-[var(--color-ink)] inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Share2 size={14} aria-hidden="true" />
                    <span>مزيد</span>
                  </button>
                )}
              </div>
            </div>

            {/* Direct Message Form */}
            <form
              onSubmit={handleSendMessage}
              className="mt-6 pt-5 border-t border-[var(--color-border)]"
            >
              <label
                htmlFor="direct-msg"
                className="block text-sm font-semibold text-[var(--color-ink)] mb-2"
              >
                تواصل مباشر عبر رسائل المنصة
              </label>
              <textarea
                id="direct-msg"
                rows={3}
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                className="w-full p-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-cream)]/50 text-sm text-[var(--color-ink)] focus:outline-none focus:border-[var(--color-green-ink)]"
              />
              <button
                type="submit"
                disabled={sendingMsg}
                className="mt-2.5 w-full h-11 rounded-lg border border-[var(--color-green-ink)] text-[var(--color-green-ink)] hover:bg-[var(--color-green)] hover:text-white hover:border-[var(--color-green)] text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-60"
              >
                <MessageSquare size={16} aria-hidden="true" />
                <span>{sendingMsg ? 'جاري الإرسال...' : 'إرسال رسالة للبائع'}</span>
              </button>
              {msgSuccess && (
                <p className="mt-2 text-xs font-medium text-[var(--color-green-ink)]">
                  تم إرسال رسالتك بنجاح. يمكنك متابعة الرد من تبويب «المحادثات» في حسابي.
                </p>
              )}
            </form>
          </div>

          {/* Seller Card */}
          {seller && (
            <div className="bg-[var(--color-cream)] rounded-xl border border-[var(--color-border)] p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-lg bg-[var(--color-green)] text-white flex items-center justify-center shrink-0">
                    <UserIcon size={20} />
                  </div>
                  <div>
                    <p className="font-display text-base font-bold text-[var(--color-ink)]">
                      {seller.displayName}
                    </p>
                    <p className="text-xs text-[var(--color-muted)] mt-0.5">
                      {seller.city} · خبرة {seller.yearsExperience} سنة
                    </p>
                  </div>
                </div>
                {seller.verifiedAt && (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-[var(--color-green-ink)]">
                    <ShieldCheck size={15} aria-hidden="true" />
                    <span>مربي موثق</span>
                  </span>
                )}
              </div>

              <p className="mt-3 text-xs text-[var(--color-muted)] leading-relaxed">{seller.bio}</p>

              <div className="mt-4 pt-3 border-t border-[var(--color-border)] flex items-center justify-between">
                <span className="text-xs text-[var(--color-muted)] tabular-nums">
                  التقييم: {seller.rating} / 5 · إتمام {seller.totalSales} بيعة
                </span>
                <button
                  type="button"
                  onClick={() => onOpenSellerProfile(seller.userId)}
                  className="text-xs font-semibold text-[var(--color-green-ink)] hover:underline cursor-pointer"
                >
                  عرض ملف المربي وإعلاناته
                </button>
              </div>
            </div>
          )}

          {/* Report Violation Trigger */}
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => setShowReportModal(true)}
              className="inline-flex items-center gap-1.5 text-xs text-[var(--color-muted)] hover:text-red-700 dark:hover:text-red-400 cursor-pointer"
            >
              <Flag size={13} aria-hidden="true" />
              <span>إبلاغ عن مخالفة في هذا الإعلان</span>
            </button>
          </div>
        </div>
      </div>

      {/* Livestock Comparison Section */}
      <div
        id="livestock-compare-section"
        ref={compareSectionRef}
        className="mt-10 bg-[var(--color-surface)] rounded-xl border border-[var(--color-border)] p-6 space-y-5"
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-[var(--color-border)]">
          <div>
            <div className="flex items-center gap-2 text-[var(--color-green-ink)]">
              <Scale size={18} aria-hidden="true" />
              <h2 className="font-display text-xl font-bold text-[var(--color-ink)]">
                مقارنة المواشي ({compareListings.length} / 4)
              </h2>
            </div>
            <p className="mt-1 text-xs text-[var(--color-muted)]">
              أضف أكثر من إعلان لمقارنة السعر والوزن والسلالة والتحصين والموقع في جدول واحد واضح لمساعدتك في اتخاذ القرار.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {compareIds.length < 4 && availableToCompare.length > 0 && (
              <div className="flex items-center gap-2">
                <select
                  aria-label="اختر إعلاناً لإضافته إلى المقارنة"
                  value={comparePickId}
                  onChange={(e) => setComparePickId(e.target.value)}
                  className="h-10 max-w-[260px] px-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] text-xs text-[var(--color-ink)] focus:outline-none focus:border-[var(--color-green-ink)]"
                >
                  {availableToCompare.map((item) => {
                    const itemBreed = allBreeds.find((b) => b.id === item.breedId);
                    return (
                      <option key={item.id} value={item.id}>
                        {itemBreed?.name ? `${itemBreed.name} — ` : ''}
                        {item.title.slice(0, 34)} ({formatPriceSar(item.priceAmount)})
                      </option>
                    );
                  })}
                </select>
                <button
                  type="button"
                  disabled={!comparePickId}
                  onClick={() => {
                    if (comparePickId) onToggleCompare(comparePickId);
                  }}
                  className="h-10 px-3.5 rounded-lg bg-[var(--color-green)] hover:bg-[var(--color-green-hover)] text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
                >
                  <Plus size={14} aria-hidden="true" />
                  <span>إضافة للمقارنة</span>
                </button>
              </div>
            )}

            {compareListings.length >= 2 && (
              <button
                type="button"
                aria-pressed={showDiffsOnly}
                onClick={() => setShowDiffsOnly((prev) => !prev)}
                className={`h-10 px-3.5 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  showDiffsOnly
                    ? 'bg-[var(--color-cream)] border-[var(--color-green-ink)] text-[var(--color-green-ink)]'
                    : 'bg-[var(--color-surface)] border-[var(--color-border)] text-[var(--color-ink)] hover:bg-[var(--color-cream)]'
                }`}
              >
                {showDiffsOnly ? 'عرض جميع المواصفات' : 'إبراز الفروقات فقط'}
              </button>
            )}

            {compareListings.length > 0 && (
              <button
                type="button"
                onClick={onClearCompare}
                className="h-10 px-3.5 rounded-lg border border-[var(--color-border)] text-xs font-semibold text-[var(--color-muted)] hover:text-red-700 dark:hover:text-red-400 hover:bg-[var(--color-cream)] inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Trash2 size={14} aria-hidden="true" />
                <span>مسح القائمة</span>
              </button>
            )}
          </div>
        </div>

        {compareListings.length === 0 ? (
          <div className="py-8 px-6 text-center rounded-xl border border-[var(--color-border)] bg-[var(--color-cream)]/40">
            <p className="font-display text-base font-bold text-[var(--color-ink)]">
              قائمة مقارنة المواشي فارغة حالياً
            </p>
            <p className="mt-1 text-xs text-[var(--color-muted)] max-w-lg mx-auto leading-relaxed">
              ابدأ بإضافة هذا الإعلان إلى قائمة المقارنة ثم أضف إعلانات أخرى من القائمة أعلاه أو أثناء تصفح الإعلانات لمشاهدة جدول الفروقات.
            </p>
            <button
              type="button"
              onClick={() => onToggleCompare(listing.id)}
              className="mt-4 h-10 px-5 rounded-lg bg-[var(--color-green)] hover:bg-[var(--color-green-hover)] text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Scale size={14} aria-hidden="true" />
              <span>إضافة هذا الإعلان للمقارنة</span>
            </button>
          </div>
        ) : (
          (() => {
            const minPrice = Math.min(...compareListings.map((i) => i.priceAmount));
            const maxWeight = Math.max(...compareListings.map((i) => i.weightKg));
            const perKgValues = compareListings
              .filter((i) => i.weightKg > 0)
              .map((i) => Math.round(i.priceAmount / i.weightKg));
            const minPerKg = perKgValues.length > 0 ? Math.min(...perKgValues) : null;

            const comparisonRows: Array<{
              key: string;
              label: string;
              getValue: (item: Listing) => string;
              renderCell: (item: Listing) => ReactNode;
            }> = [
              {
                key: 'price',
                label: 'السعر المطلوب للرأس',
                getValue: (item) => String(item.priceAmount),
                renderCell: (item) => (
                  <div>
                    <span className="font-display text-base font-extrabold text-[var(--color-green-ink)] tabular-nums">
                      {formatPriceSar(item.priceAmount)}
                    </span>
                    {compareListings.length >= 2 && item.priceAmount === minPrice && (
                      <span className="block text-[11px] font-semibold text-[var(--color-green-ink)] mt-0.5">
                        الأقل سعراً
                      </span>
                    )}
                  </div>
                ),
              },
              {
                key: 'expectedPrice',
                label: 'السعر المتوقع / السوم',
                getValue: (item) => (item.expectedPrice ? String(item.expectedPrice) : '-'),
                renderCell: (item) => (
                  <span className="tabular-nums font-semibold text-[var(--color-ink)]">
                    {item.expectedPrice ? formatPriceSar(item.expectedPrice) : '—'}
                  </span>
                ),
              },
              {
                key: 'pricePerKg',
                label: 'التكلفة التقديرية للكيلو',
                getValue: (item) =>
                  item.weightKg > 0 ? String(Math.round(item.priceAmount / item.weightKg)) : '-',
                renderCell: (item) => {
                  const perKg = item.weightKg > 0 ? Math.round(item.priceAmount / item.weightKg) : 0;
                  return (
                    <div>
                      <span className="tabular-nums font-semibold text-[var(--color-ink)]">
                        {perKg > 0 ? `${perKg.toLocaleString('en-US')} ر.س / كجم` : '—'}
                      </span>
                      {compareListings.length >= 2 && minPerKg !== null && perKg === minPerKg && (
                        <span className="block text-[11px] font-semibold text-[var(--color-green-ink)] mt-0.5">
                          أفضل قيمة للوزن
                        </span>
                      )}
                    </div>
                  );
                },
              },
              {
                key: 'breed',
                label: 'السلالة والتصنيف',
                getValue: (item) => {
                  const b = allBreeds.find((x) => x.id === item.breedId)?.name || '';
                  const c = allCategories.find((x) => x.id === item.categoryId)?.name || '';
                  const sc = allCategories.find((x) => x.id === item.subCategoryId)?.name || '';
                  return `${b}|${c}|${sc}`;
                },
                renderCell: (item) => {
                  const b = allBreeds.find((x) => x.id === item.breedId);
                  const c = allCategories.find((x) => x.id === item.categoryId);
                  const sc = allCategories.find((x) => x.id === item.subCategoryId);
                  return (
                    <div className="space-y-0.5">
                      <p className="font-semibold text-[var(--color-ink)]">
                        {b?.name || 'غير محدد'}
                      </p>
                      <p className="text-xs text-[var(--color-muted)]">
                        {c?.name || 'أغنام'}
                        {sc ? ` · ${sc.name}` : ''}
                      </p>
                    </div>
                  );
                },
              },
              {
                key: 'weight',
                label: 'الوزن التقريبي',
                getValue: (item) => String(item.weightKg),
                renderCell: (item) => (
                  <div>
                    <span className="tabular-nums font-bold text-[var(--color-ink)]">
                      {item.weightKg} كجم
                    </span>
                    {compareListings.length >= 2 && item.weightKg === maxWeight && (
                      <span className="block text-[11px] font-semibold text-[var(--color-green-ink)] mt-0.5">
                        الأعلى وزناً
                      </span>
                    )}
                  </div>
                ),
              },
              {
                key: 'age',
                label: 'العمر التقريبي',
                getValue: (item) => String(item.ageMonths),
                renderCell: (item) => (
                  <span className="tabular-nums text-[var(--color-ink)]">
                    {item.ageMonths} أشهر
                  </span>
                ),
              },
              {
                key: 'sex',
                label: 'الجنس',
                getValue: (item) => item.sex,
                renderCell: (item) => <span className="text-[var(--color-ink)]">{item.sex}</span>,
              },
              {
                key: 'quantity',
                label: 'العدد المتاح',
                getValue: (item) => String(item.quantity),
                renderCell: (item) => (
                  <span className="tabular-nums text-[var(--color-ink)]">
                    {item.quantity} رأس
                  </span>
                ),
              },
              {
                key: 'vaccinated',
                label: 'التحصين البيطري',
                getValue: (item) => String(item.vaccinated),
                renderCell: (item) => (
                  <span
                    className={
                      item.vaccinated
                        ? 'font-semibold text-[var(--color-green-ink)]'
                        : 'text-[var(--color-muted)]'
                    }
                  >
                    {item.vaccinated ? 'محصّن (دموي ومعوي)' : 'حسب المعاينة'}
                  </span>
                ),
              },
              {
                key: 'negotiation',
                label: 'التفاوض وعروض السعر',
                getValue: (item) => {
                  const offersOn =
                    item.allowPriceOffers !== undefined
                      ? item.allowPriceOffers
                      : item.isNegotiable;
                  return `${offersOn}|${item.isNegotiable}`;
                },
                renderCell: (item) => {
                  const offersOn =
                    item.allowPriceOffers !== undefined
                      ? item.allowPriceOffers
                      : item.isNegotiable;
                  return (
                    <span className="text-[var(--color-ink)]">
                      {offersOn
                        ? 'يقبل عروض السعر (سوم)'
                        : item.isNegotiable
                        ? 'قابل للتفاوض'
                        : 'سعر نهائي'}
                    </span>
                  );
                },
              },
              {
                key: 'location',
                label: 'المنطقة والمدينة',
                getValue: (item) => `${item.regionId}|${item.city}`,
                renderCell: (item) => {
                  const reg = allRegions.find((r) => r.id === item.regionId);
                  return (
                    <span className="text-[var(--color-ink)]">
                      {reg?.name ? `${reg.name} — ${item.city}` : item.city}
                    </span>
                  );
                },
              },
              {
                key: 'seller',
                label: 'المربي والتقييم',
                getValue: (item) => item.sellerId,
                renderCell: (item) => {
                  const s = allSellers.find((x) => x.userId === item.sellerId);
                  if (!s) return <span className="text-[var(--color-muted)]">—</span>;
                  return (
                    <div>
                      <button
                        type="button"
                        onClick={() => onOpenSellerProfile(s.userId)}
                        className="font-semibold text-[var(--color-green-ink)] hover:underline text-right cursor-pointer"
                      >
                        {s.displayName}
                      </button>
                      <p className="text-xs text-[var(--color-muted)] tabular-nums mt-0.5">
                        التقييم: {s.rating.toFixed(1)} / 5 · {s.totalSales} بيعة
                      </p>
                    </div>
                  );
                },
              },
            ];

            const visibleRows =
              showDiffsOnly && compareListings.length >= 2
                ? comparisonRows.filter((row) => {
                    const values = compareListings.map((item) => row.getValue(item));
                    return new Set(values).size > 1;
                  })
                : comparisonRows;

            return (
              <div className="space-y-3">
                {compareListings.length === 1 && (
                  <p className="text-xs text-[var(--color-muted)] bg-[var(--color-cream)]/60 border border-[var(--color-border)] rounded-lg px-4 py-2.5">
                    تمت إضافة إعلان واحد إلى المقارنة. اختر إعلاناً آخر من القائمة أعلاه لإظهار الفروقات جنباً إلى جنب.
                  </p>
                )}

                <div className="overflow-x-auto rounded-xl border border-[var(--color-border)]">
                  <table className="w-full text-right text-sm border-collapse min-w-[640px]">
                    <thead>
                      <tr className="bg-[var(--color-cream)]/70 border-b border-[var(--color-border)] align-top">
                        <th className="py-4 px-4 text-xs font-bold text-[var(--color-muted)] w-44 min-w-[160px] sticky right-0 bg-[var(--color-cream)] z-10 border-l border-[var(--color-border)]">
                          مواصفات المقارنة
                        </th>
                        {compareListings.map((item) => {
                          const itemBreed = allBreeds.find((b) => b.id === item.breedId);
                          const thumbUrl = item.images[0]?.url || itemBreed?.imageUrl;
                          const isCurrent = item.id === listing.id;
                          return (
                            <th
                              key={item.id}
                              className="py-4 px-4 min-w-[200px] max-w-[260px] font-normal align-top"
                            >
                              <div className="space-y-2.5">
                                <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden bg-[var(--color-surface)] border border-[var(--color-border)]">
                                  <SafeImage
                                    src={thumbUrl}
                                    alt={item.title}
                                    className="w-full h-full object-cover"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => onToggleCompare(item.id)}
                                    aria-label={`إزالة ${item.title} من المقارنة`}
                                    className="absolute top-2 left-2 w-7 h-7 rounded-md bg-[var(--color-surface)]/90 hover:bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-ink)] flex items-center justify-center cursor-pointer"
                                  >
                                    <X size={14} aria-hidden="true" />
                                  </button>
                                </div>

                                <button
                                  type="button"
                                  onClick={() => onSelectListing(item)}
                                  className="font-display text-sm font-bold text-[var(--color-ink)] hover:text-[var(--color-green-ink)] text-right leading-snug line-clamp-2 cursor-pointer"
                                >
                                  {item.title}
                                </button>

                                {isCurrent ? (
                                  <span className="block text-[11px] font-semibold text-[var(--color-green-ink)]">
                                    الإعلان المعروض حالياً
                                  </span>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => onSelectListing(item)}
                                    className="text-xs font-semibold text-[var(--color-green-ink)] hover:underline cursor-pointer"
                                  >
                                    فتح صفحة الإعلان
                                  </button>
                                )}
                              </div>
                            </th>
                          );
                        })}
                      </tr>
                    </thead>

                    <tbody className="divide-y divide-[var(--color-border)] bg-[var(--color-surface)]">
                      {visibleRows.length === 0 ? (
                        <tr>
                          <td
                            colSpan={compareListings.length + 1}
                            className="py-6 px-4 text-center text-xs text-[var(--color-muted)]"
                          >
                            جميع المواصفات الأساسية متطابقة بين الإعلانات المختارة.
                          </td>
                        </tr>
                      ) : (
                        visibleRows.map((row) => (
                          <tr key={row.key} className="hover:bg-[var(--color-cream)]/30">
                            <th
                              scope="row"
                              className="py-3.5 px-4 text-xs font-semibold text-[var(--color-muted)] sticky right-0 bg-[var(--color-cream)]/95 z-10 border-l border-[var(--color-border)]"
                            >
                              {row.label}
                            </th>
                            {compareListings.map((item) => (
                              <td key={item.id} className="py-3.5 px-4 text-xs align-top">
                                {row.renderCell(item)}
                              </td>
                            ))}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()
        )}
      </div>

      {/* Price Offer Modal */}
      <Modal
        open={showOfferModal}
        onClose={() => setShowOfferModal(false)}
        title="تقديم عرض سعر للمربي"
        subtitle={`السعر المطلوب: ${formatPriceSar(listing.priceAmount)}${
          listing.expectedPrice ? ` · السعر المتوقع: ${formatPriceSar(listing.expectedPrice)}` : ''
        }`}
        size="md"
      >
        <form onSubmit={handleOfferSubmit} className="space-y-4">
          {offerError && (
            <p className="p-2.5 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-xs text-red-700 dark:text-red-300">
              {offerError}
            </p>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="offer-price"
                className="block text-xs font-medium text-[var(--color-muted)] mb-1"
              >
                السعر المقترح للرأس (ر.س)
              </label>
              <input
                id="offer-price"
                type="number"
                min="100"
                value={offeredPrice}
                onChange={(e) => setOfferedPrice(e.target.value)}
                required
                className="w-full h-10 px-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] text-sm text-[var(--color-ink)] tabular-nums"
              />
            </div>

            <div>
              <label
                htmlFor="offer-qty"
                className="block text-xs font-medium text-[var(--color-muted)] mb-1"
              >
                الكمية المطلوبة (بحد أقصى {listing.quantity})
              </label>
              <input
                id="offer-qty"
                type="number"
                min="1"
                max={listing.quantity}
                value={offerQuantity}
                onChange={(e) => setOfferQuantity(e.target.value)}
                required
                className="w-full h-10 px-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] text-sm text-[var(--color-ink)] tabular-nums"
              />
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[var(--color-cream)] border border-[var(--color-border)] flex items-center justify-between text-xs">
            <span className="text-[var(--color-muted)]">إجمالي قيمة العرض:</span>
            <span className="font-display text-base font-extrabold text-[var(--color-green-ink)] tabular-nums">
              {formatPriceSar(offerTotal)}
            </span>
          </div>

          <div>
            <label
              htmlFor="offer-note"
              className="block text-xs font-medium text-[var(--color-muted)] mb-1"
            >
              ملاحظات للمربي (اختياري)
            </label>
            <textarea
              id="offer-note"
              rows={3}
              value={offerNote}
              onChange={(e) => setOfferNote(e.target.value)}
              placeholder="مثال: الشراء نقداً بعد المعاينة أو طلب التوصيل..."
              className="w-full p-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] text-sm text-[var(--color-ink)] placeholder:text-[var(--color-muted)]/75"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[var(--color-border)]">
            <button
              type="button"
              onClick={() => setShowOfferModal(false)}
              className="px-4 py-2 rounded-lg border border-[var(--color-border)] text-xs font-medium text-[var(--color-muted)] hover:bg-[var(--color-cream)] cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={offerSubmitting}
              className="px-5 py-2 rounded-lg bg-[var(--color-green)] hover:bg-[var(--color-green-hover)] text-white text-xs font-semibold cursor-pointer disabled:opacity-60"
            >
              {offerSubmitting ? 'جاري الإرسال...' : 'إرسال عرض السعر'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Report Modal */}
      <Modal
        open={showReportModal}
        onClose={() => setShowReportModal(false)}
        title="إبلاغ عن مخالفة"
        subtitle="يتم مراجعة البلاغات من قِبل فريق الإشراف للحفاظ على جودة ومصداقية السوق."
        size="md"
      >
        {reportSent ? (
          <div className="p-4 rounded-lg bg-[var(--color-cream)] text-sm font-medium text-[var(--color-green-ink)]">
            تم استلام بلاغك بنجاح وسيتم مراجعته من قِبل المشرفين.
          </div>
        ) : (
          <form onSubmit={handleReportSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="rep-reason"
                className="block text-xs font-medium text-[var(--color-muted)] mb-1"
              >
                سبب البلاغ
              </label>
              <select
                id="rep-reason"
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                className="w-full h-10 px-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] text-sm text-[var(--color-ink)]"
              >
                <option value="بيانات غير مطابقة">بيانات أو صور غير مطابقة</option>
                <option value="سعر وهمي أو مضلل">سعر وهمي أو مضلل</option>
                <option value="إعلان مكرر">إعلان مكرر</option>
                <option value="مخالفة لشروط السوق">مخالفة لشروط السوق</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="rep-details"
                className="block text-xs font-medium text-[var(--color-muted)] mb-1"
              >
                تفاصيل إضافية
              </label>
              <textarea
                id="rep-details"
                rows={3}
                value={reportDetails}
                onChange={(e) => setReportDetails(e.target.value)}
                placeholder="اكتب ملاحظتك لمشرفي المنصة..."
                className="w-full p-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface)] text-sm text-[var(--color-ink)] placeholder:text-[var(--color-muted)]/75"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-[var(--color-border)]">
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="px-4 py-2 rounded-lg border border-[var(--color-border)] text-sm text-[var(--color-muted)] cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-[var(--color-green)] hover:bg-[var(--color-green-hover)] text-white text-sm font-semibold cursor-pointer"
              >
                إرسال البلاغ
              </button>
            </div>
          </form>
        )}
      </Modal>
    </section>
  );
}
