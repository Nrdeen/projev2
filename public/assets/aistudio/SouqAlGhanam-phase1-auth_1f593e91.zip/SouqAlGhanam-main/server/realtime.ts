import type http from 'node:http';
import type { Duplex } from 'node:stream';
import { WebSocket, WebSocketServer } from 'ws';
import type { AppConfig } from './config';
import type { SessionManager } from './auth/sessions';
import { authenticateUpgrade } from './wsAuth';

interface Client {
  ws: WebSocket;
  userId: string;
  sessionId: string;
}

export interface RealtimeDeps {
  httpServer: http.Server;
  config: AppConfig;
  sessions: SessionManager;
  findUser: (id: string) => { id: string; status?: string } | undefined;
  getNotificationsFor: (userId: string) => unknown[];
}

const HEARTBEAT_MS = 30_000;

export function createRealtime(deps: RealtimeDeps) {
  const wss = new WebSocketServer({ noServer: true, maxPayload: 1024 });
  const clients = new Map<WebSocket, Client>();

  const reject = (socket: Duplex, status: 401 | 403) => {
    const text = status === 401 ? 'Unauthorized' : 'Forbidden';
    socket.write(`HTTP/1.1 ${status} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
    socket.destroy();
  };

  deps.httpServer.on('upgrade', (request, socket, head) => {
    let pathname = '';
    try {
      pathname = new URL(request.url || '/', 'http://localhost').pathname;
    } catch {
      socket.destroy();
      return;
    }
    if (pathname !== '/ws') {
      socket.destroy();
      return;
    }
    const result = authenticateUpgrade(
      { origin: request.headers.origin, cookie: request.headers.cookie },
      { config: deps.config, sessions: deps.sessions, findUser: deps.findUser }
    );
    if (!result.ok) return reject(socket, result.status);

    wss.handleUpgrade(request, socket, head, (ws) => {
      clients.set(ws, { ws, userId: result.userId, sessionId: result.sessionId });
      ws.send(JSON.stringify({ type: 'notifications:init', notifications: deps.getNotificationsFor(result.userId) }));

      // Identity is fixed at handshake. Client frames are never interpreted (no `auth`/`userId` switching).
      ws.on('message', () => {});
      ws.on('close', () => clients.delete(ws));
      ws.on('error', () => clients.delete(ws));
    });
  });

  const emitToUser = (userId: string, payload: Record<string, unknown>) => {
    const raw = JSON.stringify(payload);
    for (const c of clients.values()) {
      if (c.userId === userId && c.ws.readyState === WebSocket.OPEN) c.ws.send(raw);
    }
  };

  /** Closes every socket that belongs to a revoked/expired session. */
  const closeSessions = (sessionIds: string[]) => {
    const ids = new Set(sessionIds);
    for (const c of clients.values()) {
      if (ids.has(c.sessionId)) c.ws.close(4401, 'session ended');
    }
  };

  const heartbeat = setInterval(() => {
    for (const c of clients.values()) {
      const user = deps.findUser(c.userId);
      if (!deps.sessions.isAlive(c.sessionId) || !user || user.status !== 'active') {
        c.ws.close(4401, 'session ended');
      } else if (c.ws.readyState === WebSocket.OPEN) {
        c.ws.ping();
      }
    }
  }, HEARTBEAT_MS);
  heartbeat.unref();

  const close = () => {
    clearInterval(heartbeat);
    for (const c of clients.values()) c.ws.terminate();
    clients.clear();
    wss.close();
  };

  return { emitToUser, closeSessions, close, connectionCount: () => clients.size };
}
